
def add(x, y):
    return x + y


def subtract(x, y):
    return x - y


def multiply(x, y):
    return x * y


def divide(x, y):
    return x / y


Cyan = "\033[0;36m"

import sys
import time
import os


message = Cyan + "Calculator (Made By Theo Iat)"

for char in message: #text animation
    sys.stdout.write(char)
    sys.stdout.flush()
    time.sleep(0.1)
    



print(Cyan + "ㅤ") #used this to skip line

message = "Select operation"

for char in message:
    sys.stdout.write(char)
    sys.stdout.flush()
    time.sleep(0.1)

print("ㅤ") #used this to skip line

message = "1.Add"

for char in message:
    sys.stdout.write(char)
    sys.stdout.flush()
    time.sleep(0.1)

print("ㅤ") #used this to skip line

message = "2.Subtract"

for char in message:
    sys.stdout.write(char)
    sys.stdout.flush()
    time.sleep(0.1)

print("ㅤ") #used this to skip line

message = "3.Multiply"

for char in message:
    sys.stdout.write(char)
    sys.stdout.flush()
    time.sleep(0.1)

print("ㅤ") #used this to skip line

message = "4.Divide"

for char in message:
    sys.stdout.write(char)
    sys.stdout.flush()
    time.sleep(0.1)

print("ㅤ") #used this to skip line


message = "Enter choice(1/2/3/4):"

for char in message:
    sys.stdout.write(char)
    sys.stdout.flush()
    time.sleep(0.1)
  
while True:
    
    choice = input("ㅤ")
    
    if choice in ('1', '2', '3', '4'):
        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))

    
        if choice == '1':
            print(num1, "+", num2, "=", add(num1, num2))

        elif choice == '2':
            print(num1, "-", num2, "=", subtract(num1, num2))

        elif choice == '3':
            print(num1, "*", num2, "=", multiply(num1, num2))

        elif choice == '4':
            print(num1, "/", num2, "=", divide(num1, num2))

      
        
        next_calculation = input("Would you like to make another calculation? (yes/no): ")
        if next_calculation == "no":
          break 
    
    else:
        print("Invalid Input")